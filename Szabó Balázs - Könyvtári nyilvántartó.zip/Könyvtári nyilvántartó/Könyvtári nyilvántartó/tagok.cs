﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Könyvtári_nyilvántartó
{
    class tagok
    {
        public int olvasoID { get; set; }
        public string nev { get; set; }
        public string szulDatum { get; set; }
        public string Irszam { get; set; }
        public string telepules { get; set; }
        public string utcaHsz { get; set; }
        
        public tagok(string sor2)
        {
            string[] resz2 = sor2.Split(';');
            olvasoID = Convert.ToInt32(resz2[0]);
            nev = resz2[1];
            szulDatum = resz2[2];
            Irszam = resz2[3];
            telepules = resz2[4];
            utcaHsz = resz2[5];
        }
    }
}

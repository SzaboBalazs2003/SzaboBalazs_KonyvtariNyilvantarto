﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Könyvtári_nyilvántartó
{
    class Kolcsonzes
    {
        public int kolcsonzesId { get; set; }
        public string olvasoId { get; set; }
        public string konyvId { get; set; }
        public string kolcsonzesDatuma { get; set; }
        public string visszavitelDatuma { get; set; }
        public Kolcsonzes(string sor)
        {
            {
                string[] resz = sor.Split(';');
                kolcsonzesId = Convert.ToInt32(resz[0]);
                olvasoId = (resz[1]);
                konyvId = (resz[2]);
                kolcsonzesDatuma = resz[3];
                visszavitelDatuma = resz[4];
            }
        }
    }    
}

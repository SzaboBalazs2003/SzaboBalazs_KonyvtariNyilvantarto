﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Könyvtári_nyilvántartó
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Betolt();
            Lapok();
            TagLapok();
            KolcsonLapok();
            datagrid.ItemsSource = aktuallap;
            tagokd.ItemsSource = aktuallap2;
            kolcsonzesek.ItemsSource = aktuallap3;
            prev.IsEnabled = false;
            prev2.IsEnabled = false;
            prev3.IsEnabled = false;
        }
        int oldalszam, oldalszam2, oldalszam3;
        int aktualoldal = 1, aktualoldal2 = 1, aktualoldal3 = 1;
        List<konyvek> adatok = new List<konyvek>();
        List<konyvek> aktuallap = new List<konyvek>();
        List<tagok> aktuallap2 = new List<tagok>();
        List<Kolcsonzes> aktuallap3 = new List<Kolcsonzes>();
        List<tagok> tagadatok = new List<tagok>();
        List<Kolcsonzes> kolcsonadatok = new List<Kolcsonzes>();
        public void Betolt()
        {
            foreach (var item in File.ReadAllLines("konyvek.txt"))
            {
                adatok.Add(new konyvek(item));
            }
            foreach (var item in File.ReadAllLines("tagok.txt"))
            {
                tagadatok.Add(new tagok(item));
            }
            foreach (var item in File.ReadAllLines("kolcsonzesek.txt"))
            {
                kolcsonadatok.Add(new Kolcsonzes(item));
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string ujkonyv = Convert.ToString(adatok.Count() + 1) + ";" + szerzo.Text + ";" + cim.Text + ";" + kiadaseve.Text + ";" + kiado.Text + ";" + "True";
            StreamWriter sw = File.AppendText("konyvek.txt");
            sw.WriteLine(ujkonyv);
            sw.Close();
            adatok.Clear();
            foreach (var item in File.ReadAllLines("konyvek.txt"))
            {
                adatok.Add(new konyvek(item));
            }
            Lapok();
        }
        public void Kereses()
        {
            int kereses;
            kereses = kombó.SelectedIndex;
            if (kereso1.Text == "")
            {
                datagrid.ItemsSource = aktuallap;
            }
            if (kereses == 0)
            {
                var keres = adatok.Where(x => x.szerzo.Contains(kereso1.Text));
                datagrid.ItemsSource = keres;
            }
            else if (kereses == 1)
            {
                var keres = adatok.Where(x => x.cim.Contains(kereso1.Text));
                datagrid.ItemsSource = keres;
            }
            else if (kereses == 2)
            {
                var keres = adatok.Where(x => x.kiadaseve.Contains(kereso1.Text));
                datagrid.ItemsSource = keres;
            }
            else if (kereses == 3)
            {
                var keres = adatok.Where(x => x.kiado.Contains(kereso1.Text));
                datagrid.ItemsSource = keres;
            }
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Kereses();
        }
        private void kombó_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Kereses();
        }
        public void Kereses2()
        {
            int kereses;
            kereses = kombo2.SelectedIndex;
            if (kereso2.Text == "")
            {
                tagokd.ItemsSource = aktuallap;
            }
            if (kereses == 0)
            {
                var keres = tagadatok.Where(x => x.nev.Contains(kereso2.Text));
                tagokd.ItemsSource = keres;
            }
            else if (kereses == 1)
            {
                var keres = tagadatok.Where(x => x.szulDatum.Contains(kereso2.Text));
                tagokd.ItemsSource = keres;
            }
            else if (kereses == 2)
            {
                var keres = tagadatok.Where(x => x.Irszam.Contains(kereso2.Text));
                tagokd.ItemsSource = keres;
            }
            else if (kereses == 3)
            {
                var keres = tagadatok.Where(x => x.telepules.Contains(kereso2.Text));
                tagokd.ItemsSource = keres;
            }
        }
        private void kombo2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Kereses2();
        }
        private void kereso2_TextChanged(object sender, TextChangedEventArgs e)
        {
            Kereses2();
        }
        public void Kereso3()
        {
            int kereses = kombo3.SelectedIndex;
            if (kereso3.Text == "")
            {
                kolcsonzesek.ItemsSource = aktuallap;
            }
            if (kereses == 0)
            {
                var keres = kolcsonadatok.Where(x => x.olvasoId.Contains(kereso3.Text));
                kolcsonzesek.ItemsSource = keres;
            }
            else if (kereses == 1)
            {
                var keres = kolcsonadatok.Where(x => x.konyvId.Contains(kereso3.Text));
                kolcsonzesek.ItemsSource = keres;
            }
            else if (kereses == 2)
            {
                var keres = kolcsonadatok.Where(x => x.kolcsonzesDatuma.Contains(kereso3.Text));
                kolcsonzesek.ItemsSource = keres;
            }
            else if (kereses == 3)
            {
                var keres = kolcsonadatok.Where(x => x.visszavitelDatuma.Contains(kereso3.Text));
                kolcsonzesek.ItemsSource = keres;
            }

        }
        private void kombo3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Kereso3();
        }
        private void kereso3_TextChanged(object sender, TextChangedEventArgs e)
        {
            Kereso3();
        }
        public void TagLapok()
        {
            oldalszam2 = tagadatok.Count() / 25;
            if (adatok.Count() % 25 != 0)
            {
                oldalszam2 += 1;
            }
            for (int i = 0; i < 25; i++)
            {
                aktuallap2.Add(tagadatok[i]);
            }
            aktual2.Content = Convert.ToString(aktualoldal2);
            osszes2.Content = Convert.ToString(oldalszam2);
        }
        public void KolcsonLapok()
        {
            oldalszam3 = kolcsonadatok.Count() / 25;
            if (adatok.Count() % 25 != 0)
            {
                oldalszam3 += 1;
            }
            for (int i = 0; i < 25; i++)
            {
                aktuallap3.Add(kolcsonadatok[i]);
            }
            aktual3.Content = Convert.ToString(aktualoldal3);
            osszes3.Content = Convert.ToString(oldalszam3);
        }

        public void Lapok()
        {
            oldalszam = adatok.Count() / 25;
            if (adatok.Count() % 25 != 0)
            {
                oldalszam += 1;
            }
            for (int i = 0; i < 25; i++)
            {
                aktuallap.Add(adatok[i]);
            }
            aktual.Content = Convert.ToString(aktualoldal);
            osszes.Content = Convert.ToString(oldalszam);
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int kezd = datagrid.SelectedIndex;
            int oldal = (Convert.ToInt32(aktual.Content) - 1) * 25;
            int torles = kezd + oldal;
            StreamWriter sw = new StreamWriter("konyvek.txt");
            for (int i = 0; i < adatok.Count(); i++)
            {
                if (adatok[i] == adatok[torles])
                {

                }
                else
                    sw.WriteLine(adatok[i].id + ";" + adatok[i].szerzo + ";" + adatok[i].cim + ";" + adatok[i].kiadaseve + ";" + adatok[i].kiado + ";True");
            }
            sw.Close();
            adatok.Clear();
            foreach (var item in File.ReadAllLines("konyvek.txt"))
            {
                adatok.Add(new konyvek(item));
            }
            UjraID();
            datagrid.ItemsSource = aktuallap;
        }
        private void ujtag_Click(object sender, RoutedEventArgs e)
        {
            string ujtag = Convert.ToString(tagadatok.Count() + 1) + ";" +  Nev.Text + ";" + SzulDatum.Text + ";" + Irszam.Text + ";" + Telepules.Text + ";" + UtcaHsz.Text;
            StreamWriter sw = File.AppendText("tagok.txt");
            sw.WriteLine(ujtag);
            sw.Close();    
            tagadatok.Clear();
            foreach (var item in File.ReadAllLines("tagok.txt"))
            {
                tagadatok.Add(new tagok(item));
            }
            TagLapok();
        }
        private void prev_Click(object sender, RoutedEventArgs e)
        {
                datagrid.ItemsSource = null;
                aktualoldal -= 1;
                int index = aktualoldal * 25 - 25;
                if (Convert.ToInt32(aktual.Content) > 2)
                {
                    aktuallap.Clear();
                    prev.IsEnabled = true;
                    for (int i = index; i < index+25; i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
                else
                {
                    aktuallap.Clear();
                    prev.IsEnabled = false;
                    for (int i = index; i < index + 25; i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
                datagrid.ItemsSource = aktuallap;
                aktual.Content = Convert.ToString(aktualoldal);
                next.IsEnabled = true;
        }
        private void prev2_Click(object sender, RoutedEventArgs e)
        {
            tagokd.ItemsSource = null;
            aktualoldal2 -= 1;
            int index = aktualoldal2 * 25 - 25;
            if (Convert.ToInt32(aktual2.Content) > 2)
            {
                aktuallap2.Clear();
                prev2.IsEnabled = true;
                for (int i = index; i < index + 25; i++)
                {
                    aktuallap2.Add(tagadatok[i]);
                }
            }
            else
            {
                aktuallap2.Clear();
                prev2.IsEnabled = false;
                for (int i = index; i < index + 25; i++)
                {
                    aktuallap2.Add(tagadatok[i]);
                }
            }
            tagokd.ItemsSource = aktuallap2;
            aktual2.Content = Convert.ToString(aktualoldal2);
            next2.IsEnabled = true;
        }
        private void modositas2_Click(object sender, RoutedEventArgs e)
        {
            int kezd = tagokd.SelectedIndex;
            int oldal = (Convert.ToInt32(aktual2.Content) - 1) * 25;
            int index = kezd + oldal;
            tagadatok[index].nev = Nev.Text;
            tagadatok[index].szulDatum = SzulDatum.Text;
            tagadatok[index].Irszam = Irszam.Text;
            tagadatok[index].telepules = Telepules.Text;
            tagadatok[index].utcaHsz = UtcaHsz.Text;
            StreamWriter sw = new StreamWriter("tagok.txt");
            foreach (var item in tagadatok)
            {
                sw.WriteLine(item.olvasoID + ";" + item.nev + ";" + item.szulDatum + ";" + item.Irszam + ";" + item.telepules + ";" + item.utcaHsz);
            }
            sw.Close();
            tagokd.ItemsSource = aktuallap2;
        }
        private void konymod_Click(object sender, RoutedEventArgs e)
        {
            int kezd = datagrid.SelectedIndex;
            int oldal = (Convert.ToInt32(aktual.Content) - 1) * 25;
            int index = kezd + oldal;
            adatok[index].szerzo = szerzo.Text;
            adatok[index].cim = cim.Text;
            adatok[index].kiadaseve = kiadaseve.Text;
            adatok[index].kiado = kiado.Text;
            StreamWriter sw = new StreamWriter("konyvek.txt");
            foreach (var item in adatok)
            {
                sw.WriteLine(item.id + ";" + item.szerzo + ";" + item.cim + ";" + item.kiadaseve + ";" + item.kiado + ";" + item.kolcson);
            }
            sw.Close();
            datagrid.ItemsSource = aktuallap;
        }
        private void kolcsonmod_Click(object sender, RoutedEventArgs e)
        {
            int kezd = kolcsonzesek.SelectedIndex;
            int oldal = (Convert.ToInt32(aktual3.Content) - 1) * 25;
            int index = kezd + oldal;
            kolcsonadatok[index].olvasoId = olvasId.Text;
            kolcsonadatok[index].konyvId = konyId.Text;
            kolcsonadatok[index].kolcsonzesDatuma = kolcsKezd.Text;
            kolcsonadatok[index].visszavitelDatuma = visszaDatum.Text;
            StreamWriter sw = new StreamWriter("kolcsonzesek.txt");
            foreach (var item in kolcsonadatok)
            {
                sw.WriteLine(item.kolcsonzesId + ";" + item.olvasoId + ";" + item.konyvId + ";" + item.kolcsonzesDatuma + ";" + item.visszavitelDatuma);
            }
            sw.Close();
            kolcsonzesek.ItemsSource = aktuallap3;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string ujkolcson = Convert.ToString(kolcsonadatok.Count() + 1) + ";" + olvasId.Text + ";" + konyId.Text + ";" + kolcsKezd.Text + ";" + visszaDatum.Text;
            StreamWriter sw = File.AppendText("kolcsonzesek.txt");
            sw.WriteLine(ujkolcson);
            sw.Close();
            kolcsonadatok.Clear();
            foreach (var item in File.ReadAllLines("kolcsonzesek.txt"))
            {
                kolcsonadatok.Add(new Kolcsonzes(item));
            }
            KolcsonLapok();
        }
        public void UjraID()
        {
            for (int i = 0; i < adatok.Count(); i++)
            {
                adatok[i].id = i + 1;
            }
        }
        public void UjraID2()
        {
            for (int i = 0; i < tagadatok.Count(); i++)
            {
                tagadatok[i].olvasoID = i + 1;
            }
        }
        private void torles_Click(object sender, RoutedEventArgs e)
        {
            int kezd = tagokd.SelectedIndex;
            int oldal = (Convert.ToInt32(aktual2.Content) - 1) * 25;
            int torles = kezd + oldal;
            StreamWriter sw = new StreamWriter("tagok.txt");
            for (int i = 0; i < tagadatok.Count(); i++)
            {
                if (tagadatok[i] == tagadatok[torles])
                {

                }
                else
                    sw.WriteLine(tagadatok[i].olvasoID + ";" + tagadatok[i].nev + ";" + tagadatok[i].szulDatum + ";" + tagadatok[i].Irszam + ";" + tagadatok[i].telepules + ";" + tagadatok[i].utcaHsz);
            }
            sw.Close();
            tagadatok.Clear();
            foreach (var item in File.ReadAllLines("tagok.txt"))
            {
                tagadatok.Add(new tagok(item));
            }
            UjraID2();
            tagokd.ItemsSource = aktuallap2;

        }

        private void prev3_Click(object sender, RoutedEventArgs e)
        {
            kolcsonzesek.ItemsSource = null;
            aktualoldal3 -= 1;
            int index = aktualoldal3 * 25 - 25;
            if (Convert.ToInt32(aktual3.Content) > 2)
            {
                aktuallap3.Clear();
                prev3.IsEnabled = true;
                for (int i = index; i < index + 25; i++)
                {
                    aktuallap3.Add(kolcsonadatok[i]);
                }
            }
            else
            {
                aktuallap3.Clear();
                prev3.IsEnabled = false;
                for (int i = index; i < index + 25; i++)
                {
                    aktuallap3.Add(kolcsonadatok[i]);
                }
            }
            kolcsonzesek.ItemsSource = aktuallap3;
            aktual3.Content = Convert.ToString(aktualoldal3);
            next3.IsEnabled = true;
        }

        private void next3_Click(object sender, RoutedEventArgs e)
        {
            kolcsonzesek.ItemsSource = null;
            int index = aktualoldal3 * 25;
            aktualoldal3 += 1;
            if (Convert.ToInt32(aktual3.Content) < Convert.ToInt32(osszes3.Content) - 1)
            {
                aktuallap3.Clear();
                next3.IsEnabled = true;
                for (int i = index; i < index + 25; i++)
                {
                    aktuallap3.Add(kolcsonadatok[i]);
                }
            }
            else
            {
                aktuallap3.Clear();
                next3.IsEnabled = true;
                if (index + 25 > kolcsonadatok.Count())
                {
                    for (int i = index; i < kolcsonadatok.Count(); i++)
                    {
                        aktuallap3.Add(kolcsonadatok[i]);
                    }
                }
                next3.IsEnabled = false;
            }
            kolcsonzesek.ItemsSource = aktuallap3;
            aktual3.Content = Convert.ToString(aktualoldal3);
            prev3.IsEnabled = true;
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            datagrid.ItemsSource = null;
            int index = aktualoldal * 25;
            aktualoldal += 1;
            if (Convert.ToInt32(aktual.Content) < Convert.ToInt32(osszes.Content)-1)
            {
                aktuallap.Clear();
                next.IsEnabled = true;
                if (index + 25 > adatok.Count())
                {
                    for (int i = index; i < adatok.Count(); i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
                else
                {
                    for (int i = index; i < index + 25; i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
            }
            else
            {
                aktuallap.Clear();
                next.IsEnabled = true;
                if (index + 25 > adatok.Count())
                {
                    for (int i = index; i < adatok.Count(); i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
                else
                {
                    for (int i = index; i < index + 25; i++)
                    {
                        aktuallap.Add(adatok[i]);
                    }
                }
                next.IsEnabled = false;
            }
            datagrid.ItemsSource = aktuallap;
            aktual.Content = Convert.ToString(aktualoldal);
            prev.IsEnabled = true;
        }
        private void next2_Click(object sender, RoutedEventArgs e)
        {
            tagokd.ItemsSource = null;
            int index = aktualoldal2 * 25;
            aktualoldal2 += 1;
            if (Convert.ToInt32(aktual2.Content) < Convert.ToInt32(osszes2.Content) - 1)
            {
                aktuallap2.Clear();
                next2.IsEnabled = true;
                if (index + 25 > tagadatok.Count())
                {
                    for (int i = index; i < tagadatok.Count(); i++)
                    {
                        aktuallap2.Add(tagadatok[i]);
                    }
                }
                else
                {
                    for (int i = index; i < index + 25; i++)
                    {
                        aktuallap2.Add(tagadatok[i]);
                    }
                }
            }
            else
            {
                aktuallap2.Clear();
                next2.IsEnabled = true;
                if (index + 25 > tagadatok.Count())
                {
                    for (int i = index; i < tagadatok.Count(); i++)
                    {
                        aktuallap2.Add(tagadatok[i]);
                    }
                }
                else
                {
                    for (int i = index; i < index + 25; i++)
                    {
                        aktuallap2.Add(tagadatok[i]);
                    }
                }
                next2.IsEnabled = false;
            }
            tagokd.ItemsSource = aktuallap2;
            aktual2.Content = Convert.ToString(aktualoldal2);
            prev2.IsEnabled = true;
        }
    }
}
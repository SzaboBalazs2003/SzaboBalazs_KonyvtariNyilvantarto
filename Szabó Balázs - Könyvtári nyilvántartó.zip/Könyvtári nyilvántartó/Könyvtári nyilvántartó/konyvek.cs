﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Könyvtári_nyilvántartó
{
    class konyvek
    {
        public int id { get; set; }
        public string szerzo { get; set; }
        public string cim { get; set; }
        public string kiadaseve { get; set; }
        public string kiado { get; set; }
        public bool kolcson { get; set; }
        public konyvek(string sor)
        {
            string[] resz = sor.Split(';');
            id = Convert.ToInt32(resz[0]);
            szerzo = resz[1];
            cim = resz[2];
            kiadaseve = resz[3];
            kiado = resz[4];
            if (resz[5] == "True")
            {
                kolcson = true;
            }
            else
                kolcson = false;
        }
    }
}
